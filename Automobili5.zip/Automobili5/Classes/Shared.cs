﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Automobili5.Classes
{
    public static class Shared
    {
        public static SqlConnection getConnection()
        {
            string conn = ConfigurationManager.ConnectionStrings["Automobili"].ToString();
            SqlConnection myConn = new SqlConnection(conn); return myConn;
        }
    }
}
  