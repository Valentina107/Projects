﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Automobili5.Classes
{
    public class Automobili
    {
        public int id_auto { get; set; }
        public string marca { get; set; }
        public int kilometri { get; set; }
        public DateTime data_fabricazione { get; set; }
        public string carburante { get; set; }
        public string foto { get; set; }
        public int prezzo { get; set; }   

        public static List <Automobili> lista_auto= new List<Automobili>();

    }

   
}

