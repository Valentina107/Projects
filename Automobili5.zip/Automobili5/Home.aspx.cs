﻿using Automobili5.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Automobili5
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Automobili.lista_auto.Clear();
            if (!IsPostBack)
            {
                try
                {
                    SqlConnection connection = new SqlConnection();
                    connection.ConnectionString = ConfigurationManager.ConnectionStrings["Automobili"].ToString();
                    connection.Open();
                    
                    SqlCommand comando= new SqlCommand();
                    comando.CommandText = "select * from Automobili";
                    comando.Connection = connection;

                    SqlDataReader reader= comando.ExecuteReader();  
                    while (reader.Read()) { 
                      Automobili auto= new Automobili();
                        auto.id_auto = Convert.ToInt32(reader["id"]);
                        auto.marca = reader["marca"].ToString();  
                        auto.data_fabricazione =  DateTime.Parse(reader["data_fabricazione"].ToString());
                        auto.carburante = reader["carburante"].ToString() ;
                        auto.kilometri = Convert.ToInt32(reader["Kilometri"]);
                        auto.foto = reader["foto"].ToString();
                        auto.prezzo = Convert.ToInt32(reader["prezzo"].ToString());

                        Automobili.lista_auto.Add(auto);
                       
                    }
                    Repeater1.DataSource = Automobili.lista_auto; Repeater1.DataBind();
                    connection.Close();
                }

                catch (Exception ex)
                {
                    errorDiv.InnerText=ex.Message;
                    return;
                }

        
                

            }
        }
    }
}