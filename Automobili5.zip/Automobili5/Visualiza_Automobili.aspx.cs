﻿using Automobili5.Classes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Automobili5
{
    public partial class Visualiza_Automobili : System.Web.UI.Page
    {
       
        
    }
}